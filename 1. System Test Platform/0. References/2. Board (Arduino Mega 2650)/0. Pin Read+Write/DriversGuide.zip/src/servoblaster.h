#ifndef _SERVOBLASTER_H_
#define _SERVOBLASTER_H_

void writeServoBlaster(int channel, int value);

#endif //_SERVOBLASTER_H_